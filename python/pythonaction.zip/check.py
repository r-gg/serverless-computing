#!/usr/bin/env python


def check_it(args):

    print(args)
