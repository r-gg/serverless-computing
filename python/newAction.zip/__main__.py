#!/usr/bin/env python

from minio import Minio
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import classification_report
import numpy as np
import gzip
import os
import pickle
from kafka import KafkaProducer

kafka_url = "kafkica.openwhisk.svc.cluster.local"

mini_x = None
mini_y = None

def merge_models(model1, model2_coefs, model2_intercepts, mini_x, mini_y):
    averaged_coefs = [0.5 * (w1 + w2) for w1, w2 in zip(model1.coefs_, model2_coefs)]
    averaged_intercepts = [0.5 * (b1 + b2) for b1, b2 in zip(model1.intercepts_, model2_intercepts)]

    # Create a new model with the averaged weights
    merged_model = MLPClassifier(hidden_layer_sizes=model1.hidden_layer_sizes, activation=model1.activation,
                                solver=model1.solver, alpha=model1.alpha, batch_size=model1.batch_size,
                                learning_rate=model1.learning_rate, max_iter=model1.max_iter,
                                random_state=model1.random_state)
    merged_model.fit(mini_x, mini_y) # just to initialize the variables
    merged_model.coefs_ = averaged_coefs
    merged_model.intercepts_ = averaged_intercepts
    return merged_model


def download_and_extract(client, bucket_name, object_name, file_path):
    client.fget_object(bucket_name, object_name, file_path)
    with gzip.open(file_path, 'rb') as f_in:
        if 'images' in object_name:
            return np.frombuffer(f_in.read(), np.uint8).reshape(-1, 784)  # 28x28 images
        else:
            return np.frombuffer(f_in.read(), np.uint8)

def train_mnist_model(minio_client, bucket_name, part_num):
    local_dir = '/tmp/mnist_data_part{}'.format(part_num)
    os.makedirs(local_dir, exist_ok=True)

    # Download and load dataset parts
    train_images = download_and_extract(minio_client, bucket_name, f'part{part_num}_mnist_train_images.gz', os.path.join(local_dir, 'train_images.gz'))
    train_labels = download_and_extract(minio_client, bucket_name, f'part{part_num}_mnist_train_labels.gz', os.path.join(local_dir, 'train_labels.gz'))
    test_images = download_and_extract(minio_client, bucket_name, f'part{part_num}_mnist_test_images.gz', os.path.join(local_dir, 'test_images.gz'))
    test_labels = download_and_extract(minio_client, bucket_name, f'part{part_num}_mnist_test_labels.gz', os.path.join(local_dir, 'test_labels.gz'))

    # Train neural network
    clf = MLPClassifier(hidden_layer_sizes=(50,), max_iter=50, solver='sgd', random_state=1, verbose=True)
    clf.fit(train_images, train_labels)
    predictions = clf.predict(test_images)
    return classification_report(test_labels, predictions), clf


def main(args):
    # print(args)
    part_number = 1
    producer = KafkaProducer(
        bootstrap_servers=kafka_url
    )

    producer.send('federated', f'Openwhisk Action with split number {part_number} started'.encode())
    producer.flush()

    client = Minio(
        "minio-operator9000.minio-dev.svc.cluster.local:9000",
        secure=False
    )
    dataset_bucket_name = 'dataset-bucket'
    

    classification_report = train_mnist_model(client, dataset_bucket_name, part_number)

    # producer.send('federated', f'Openwhisk Action with split number {part_number} finished')
    # producer.flush()



    return classification_report


if __name__ == '__main__':
    import sys
    sys.exit(main(sys.argv))